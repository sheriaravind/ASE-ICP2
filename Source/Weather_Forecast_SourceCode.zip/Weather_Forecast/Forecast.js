angular.module('weather_forecast', [])
    .controller('weathercontroller', function($scope, $http) {

        $scope.getWeather = function() {
            var state_name = $scope.state;
            var city_name = $scope.city;
            $http.get('https://api.wunderground.com/api/a584b532b673ec2f/conditions/q/'+state_name+'/'+city_name+'%20.json').success(function(data) {
                console.log(data);
                temp = data.current_observation.temp_f;
                feels = data.current_observation.feelslike_f;
                wind = data.current_observation.wind_mph;
                pressure = data.current_observation.pressure_mb;
                humidity = data.current_observation.relative_humidity;
                icon = data.current_observation.icon_url;
                weather = data.current_observation.weather;
                console.log(temp);
                $scope.currentweather = {
                    html: "Currently " + temp + " &deg; F and " + weather + ""
                }
                $scope.currentweather1 = {
                    html: "Feels like" + feels +" &deg; F " + ",     " + "Humidity: " + humidity
                }

                $scope.currentweather2 = {
                    html: "Wind: " + wind+"  mph" + ",     " + "Pressure: " + pressure+"  mb"
                }
                $scope.currentIcon = {
                    html: "<img src='" + icon + "'/>"
                }

            })
        }

    });